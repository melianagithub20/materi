// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxnetutils.pas' rev: 10.00

#ifndef FrxnetutilsHPP
#define FrxnetutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxnetutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString __fastcall GMTDateTimeToRFCDateTime(const System::TDateTime D);
extern PACKAGE AnsiString __fastcall DateTimeToRFCDateTime(const System::TDateTime D);
extern PACKAGE AnsiString __fastcall PadLeft(const AnsiString S, const char PadChar, const int Len);
extern PACKAGE AnsiString __fastcall PadRight(const AnsiString S, const char PadChar, const int Len);
extern PACKAGE AnsiString __fastcall Base64Encode(const AnsiString S);
extern PACKAGE AnsiString __fastcall Base64Decode(const AnsiString S);
extern PACKAGE AnsiString __fastcall GetFileMIMEType(const AnsiString FileName);
extern PACKAGE AnsiString __fastcall GetSocketErrorText(const int ErrorCode);
extern PACKAGE void __fastcall PMessages(void);
extern PACKAGE AnsiString __fastcall ParseHeaderField(const AnsiString Field, const AnsiString Header);

}	/* namespace Frxnetutils */
using namespace Frxnetutils;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxnetutils
