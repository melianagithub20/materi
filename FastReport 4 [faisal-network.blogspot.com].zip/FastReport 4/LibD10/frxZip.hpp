// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxzip.pas' rev: 10.00

#ifndef FrxzipHPP
#define FrxzipHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Frxzlib.hpp>	// Pascal unit
#include <Frxgzip.hpp>	// Pascal unit
#include <Frxutils.hpp>	// Pascal unit
#include <Frxfileutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxzip
{
//-- type declarations -------------------------------------------------------
typedef unsigned DWORD;

class DELPHICLASS TfrxZipArchive;
class PASCALIMPLEMENTATION TfrxZipArchive : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	AnsiString FRootFolder;
	Classes::TStringList* FErrors;
	Classes::TStringList* FFileList;
	AnsiString FComment;
	Classes::TNotifyEvent FProgress;
	int __fastcall GetCount(void);
	
public:
	__fastcall TfrxZipArchive(void);
	__fastcall virtual ~TfrxZipArchive(void);
	void __fastcall Clear(void);
	void __fastcall AddFile(const AnsiString FileName);
	void __fastcall AddDir(const AnsiString DirName);
	void __fastcall SaveToStream(const Classes::TStream* Stream);
	void __fastcall SaveToFile(const AnsiString Filename);
	__property AnsiString RootFolder = {read=FRootFolder, write=FRootFolder};
	__property Classes::TStringList* Errors = {read=FErrors};
	__property AnsiString Comment = {read=FComment, write=FComment};
	__property int FileCount = {read=GetCount, nodefault};
	__property Classes::TNotifyEvent OnProgress = {read=FProgress, write=FProgress};
};


class DELPHICLASS TfrxZipLocalFileHeader;
class PASCALIMPLEMENTATION TfrxZipLocalFileHeader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	unsigned FLocalFileHeaderSignature;
	Word FVersion;
	Word FGeneralPurpose;
	Word FCompressionMethod;
	unsigned FCrc32;
	Word FLastModFileDate;
	Word FLastModFileTime;
	unsigned FCompressedSize;
	unsigned FUnCompressedSize;
	AnsiString FExtraField;
	AnsiString FFileName;
	Word FFileNameLength;
	Word FExtraFieldLength;
	void __fastcall SetExtraField(const AnsiString Value);
	void __fastcall SetFileName(const AnsiString Value);
	
public:
	__fastcall TfrxZipLocalFileHeader(void);
	void __fastcall SaveToStream(const Classes::TStream* Stream);
	__property unsigned LocalFileHeaderSignature = {read=FLocalFileHeaderSignature, nodefault};
	__property Word Version = {read=FVersion, write=FVersion, nodefault};
	__property Word GeneralPurpose = {read=FGeneralPurpose, write=FGeneralPurpose, nodefault};
	__property Word CompressionMethod = {read=FCompressionMethod, write=FCompressionMethod, nodefault};
	__property Word LastModFileTime = {read=FLastModFileTime, write=FLastModFileTime, nodefault};
	__property Word LastModFileDate = {read=FLastModFileDate, write=FLastModFileDate, nodefault};
	__property unsigned Crc32 = {read=FCrc32, write=FCrc32, nodefault};
	__property unsigned CompressedSize = {read=FCompressedSize, write=FCompressedSize, nodefault};
	__property unsigned UnCompressedSize = {read=FUnCompressedSize, write=FUnCompressedSize, nodefault};
	__property Word FileNameLength = {read=FFileNameLength, write=FFileNameLength, nodefault};
	__property Word ExtraFieldLength = {read=FExtraFieldLength, write=FExtraFieldLength, nodefault};
	__property AnsiString FileName = {read=FFileName, write=SetFileName};
	__property AnsiString ExtraField = {read=FExtraField, write=SetExtraField};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxZipLocalFileHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxZipCentralDirectory;
class PASCALIMPLEMENTATION TfrxZipCentralDirectory : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	unsigned FEndOfChentralDirSignature;
	Word FNumberOfTheDisk;
	Word FTotalOfEntriesCentralDirOnDisk;
	Word FNumberOfTheDiskStartCentralDir;
	Word FTotalOfEntriesCentralDir;
	unsigned FSizeOfCentralDir;
	unsigned FOffsetStartingDiskDir;
	AnsiString FComment;
	Word FCommentLength;
	void __fastcall SetComment(const AnsiString Value);
	
public:
	__fastcall TfrxZipCentralDirectory(void);
	void __fastcall SaveToStream(const Classes::TStream* Stream);
	__property unsigned EndOfChentralDirSignature = {read=FEndOfChentralDirSignature, nodefault};
	__property Word NumberOfTheDisk = {read=FNumberOfTheDisk, write=FNumberOfTheDisk, nodefault};
	__property Word NumberOfTheDiskStartCentralDir = {read=FNumberOfTheDiskStartCentralDir, write=FNumberOfTheDiskStartCentralDir, nodefault};
	__property Word TotalOfEntriesCentralDirOnDisk = {read=FTotalOfEntriesCentralDirOnDisk, write=FTotalOfEntriesCentralDirOnDisk, nodefault};
	__property Word TotalOfEntriesCentralDir = {read=FTotalOfEntriesCentralDir, write=FTotalOfEntriesCentralDir, nodefault};
	__property unsigned SizeOfCentralDir = {read=FSizeOfCentralDir, write=FSizeOfCentralDir, nodefault};
	__property unsigned OffsetStartingDiskDir = {read=FOffsetStartingDiskDir, write=FOffsetStartingDiskDir, nodefault};
	__property Word CommentLength = {read=FCommentLength, write=FCommentLength, nodefault};
	__property AnsiString Comment = {read=FComment, write=SetComment};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxZipCentralDirectory(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxZipFileHeader;
class PASCALIMPLEMENTATION TfrxZipFileHeader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	unsigned FCentralFileHeaderSignature;
	unsigned FRelativeOffsetLocalHeader;
	unsigned FUnCompressedSize;
	unsigned FCompressedSize;
	unsigned FCrc32;
	unsigned FExternalFileAttribute;
	AnsiString FExtraField;
	AnsiString FFileComment;
	AnsiString FFileName;
	Word FCompressionMethod;
	Word FDiskNumberStart;
	Word FLastModFileDate;
	Word FLastModFileTime;
	Word FVersionMadeBy;
	Word FGeneralPurpose;
	Word FFileNameLength;
	Word FInternalFileAttribute;
	Word FExtraFieldLength;
	Word FVersionNeeded;
	Word FFileCommentLength;
	void __fastcall SetExtraField(const AnsiString Value);
	void __fastcall SetFileComment(const AnsiString Value);
	void __fastcall SetFileName(const AnsiString Value);
	
public:
	__fastcall TfrxZipFileHeader(void);
	void __fastcall SaveToStream(const Classes::TStream* Stream);
	__property unsigned CentralFileHeaderSignature = {read=FCentralFileHeaderSignature, nodefault};
	__property Word VersionMadeBy = {read=FVersionMadeBy, nodefault};
	__property Word VersionNeeded = {read=FVersionNeeded, nodefault};
	__property Word GeneralPurpose = {read=FGeneralPurpose, write=FGeneralPurpose, nodefault};
	__property Word CompressionMethod = {read=FCompressionMethod, write=FCompressionMethod, nodefault};
	__property Word LastModFileTime = {read=FLastModFileTime, write=FLastModFileTime, nodefault};
	__property Word LastModFileDate = {read=FLastModFileDate, write=FLastModFileDate, nodefault};
	__property unsigned Crc32 = {read=FCrc32, write=FCrc32, nodefault};
	__property unsigned CompressedSize = {read=FCompressedSize, write=FCompressedSize, nodefault};
	__property unsigned UnCompressedSize = {read=FUnCompressedSize, write=FUnCompressedSize, nodefault};
	__property Word FileNameLength = {read=FFileNameLength, write=FFileNameLength, nodefault};
	__property Word ExtraFieldLength = {read=FExtraFieldLength, write=FExtraFieldLength, nodefault};
	__property Word FileCommentLength = {read=FFileCommentLength, write=FFileCommentLength, nodefault};
	__property Word DiskNumberStart = {read=FDiskNumberStart, write=FDiskNumberStart, nodefault};
	__property Word InternalFileAttribute = {read=FInternalFileAttribute, write=FInternalFileAttribute, nodefault};
	__property unsigned ExternalFileAttribute = {read=FExternalFileAttribute, write=FExternalFileAttribute, nodefault};
	__property unsigned RelativeOffsetLocalHeader = {read=FRelativeOffsetLocalHeader, write=FRelativeOffsetLocalHeader, nodefault};
	__property AnsiString FileName = {read=FFileName, write=SetFileName};
	__property AnsiString ExtraField = {read=FExtraField, write=SetExtraField};
	__property AnsiString FileComment = {read=FFileComment, write=SetFileComment};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxZipFileHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxZipLocalFile;
class PASCALIMPLEMENTATION TfrxZipLocalFile : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	TfrxZipLocalFileHeader* FLoacalFileHeader;
	Classes::TMemoryStream* FFileData;
	unsigned FOffset;
	
public:
	__fastcall TfrxZipLocalFile(void);
	__fastcall virtual ~TfrxZipLocalFile(void);
	void __fastcall SaveToStream(const Classes::TStream* Stream);
	__property TfrxZipLocalFileHeader* LocalFileHeader = {read=FLoacalFileHeader};
	__property Classes::TMemoryStream* FileData = {read=FFileData, write=FFileData};
	__property unsigned Offset = {read=FOffset, write=FOffset, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxzip */
using namespace Frxzip;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxzip
