// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxunicodeutils.pas' rev: 10.00

#ifndef FrxunicodeutilsHPP
#define FrxunicodeutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxunicodeutils
{
//-- type declarations -------------------------------------------------------
struct TWString
{
	
public:
	WideString WString;
	System::TObject* Obj;
} ;

class DELPHICLASS TWideStrings;
class PASCALIMPLEMENTATION TWideStrings : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
public:
	WideString operator[](int Index) { return Strings[Index]; }
	
private:
	Classes::TList* FWideStringList;
	WideString __fastcall Get(int Index);
	void __fastcall Put(int Index, const WideString S);
	System::TObject* __fastcall GetObject(int Index);
	void __fastcall PutObject(int Index, const System::TObject* Value);
	void __fastcall ReadData(Classes::TReader* Reader);
	void __fastcall ReadDataW(Classes::TReader* Reader);
	void __fastcall WriteDataW(Classes::TWriter* Writer);
	WideString __fastcall GetTextStr();
	void __fastcall SetTextStr(const WideString Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	
public:
	__fastcall TWideStrings(void);
	__fastcall virtual ~TWideStrings(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	int __fastcall Count(void);
	void __fastcall Clear(void);
	void __fastcall Delete(int Index);
	int __fastcall Add(const WideString S);
	void __fastcall AddStrings(TWideStrings* Strings);
	int __fastcall AddObject(const WideString S, System::TObject* AObject);
	int __fastcall IndexOf(const WideString S);
	void __fastcall Insert(int Index, const WideString S);
	void __fastcall LoadFromFile(const WideString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall LoadFromWStream(Classes::TStream* Stream);
	void __fastcall SaveToFile(const WideString FileName);
	void __fastcall SaveToStream(Classes::TStream* Stream);
	__property System::TObject* Objects[int Index] = {read=GetObject, write=PutObject};
	__property WideString Strings[int Index] = {read=Get, write=Put/*, default*/};
	__property WideString Text = {read=GetTextStr, write=SetTextStr};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE WideString __fastcall AnsiToUnicode(const AnsiString s, unsigned Charset);

}	/* namespace Frxunicodeutils */
using namespace Frxunicodeutils;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxunicodeutils
