// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Rc_apiref.pas' rev: 10.00

#ifndef Rc_apirefHPP
#define Rc_apirefHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Rc_algref.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rc_apiref
{
//-- type declarations -------------------------------------------------------
typedef Byte word8;

typedef Word word16;

typedef unsigned word32;

typedef Byte TByteArray[2147483647];

typedef TByteArray *PByte;

struct keyInstance;
typedef keyInstance *PkeyInstance;

#pragma pack(push,1)
struct keyInstance
{
	
public:
	Byte direction;
	int keyLen;
	char keyMaterial[65];
	int blockLen;
	Byte keySched[15][4][8];
} ;
#pragma pack(pop)

typedef keyInstance  TkeyInstance;

struct cipherInstance;
typedef cipherInstance *PcipherInstance;

#pragma pack(push,1)
struct cipherInstance
{
	
public:
	Byte mode;
	Byte IV[16];
	int blockLen;
} ;
#pragma pack(pop)

typedef cipherInstance  TcipherInstance;

//-- var, const, procedure ---------------------------------------------------
static const Shortint MAXBC = 0x8;
static const Shortint MAXKC = 0x8;
static const Shortint MAXROUNDS = 0xe;
static const Shortint DIR_ENCRYPT = 0x0;
static const Shortint DIR_DECRYPT = 0x1;
static const Shortint MODE_ECB = 0x1;
static const Shortint MODE_CBC = 0x2;
static const Shortint MODE_CFB1 = 0x3;
static const Shortint rTRUE = 0x1;
static const Shortint rFALSE = 0x0;
static const Byte BITSPERBLOCK = 0x80;
static const Shortint BAD_KEY_DIR = -1;
static const Shortint BAD_KEY_MAT = -2;
static const Shortint BAD_KEY_INSTANCE = -3;
static const Shortint BAD_CIPHER_MODE = -4;
static const Shortint BAD_CIPHER_STATE = -5;
static const Shortint BAD_CIPHER_INSTANCE = -7;
static const Shortint MAX_KEY_SIZE = 0x40;
static const Shortint MAX_IV_SIZE = 0x10;
extern PACKAGE int __fastcall makeKey(PkeyInstance key, Byte direction, int keyLen, char * keyMaterial);
extern PACKAGE int __fastcall cipherInit(PcipherInstance cipher, Byte mode, char * IV);
extern PACKAGE int __fastcall blocksEnCrypt(PcipherInstance cipher, PkeyInstance key, PByte input, int inputLen, PByte outBuffer);
extern PACKAGE int __fastcall blocksDeCrypt(PcipherInstance cipher, PkeyInstance key, PByte input, int inputLen, PByte outBuffer);
extern PACKAGE int __fastcall cipherUpdateRounds(PcipherInstance cipher, PkeyInstance key, PByte input, int inputLen, PByte outBuffer, int iRounds);

}	/* namespace Rc_apiref */
using namespace Rc_apiref;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Rc_apiref
