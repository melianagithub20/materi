// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxxmlserializer.pas' rev: 10.00

#ifndef FrxxmlserializerHPP
#define FrxxmlserializerHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Frxxml.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxxmlserializer
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TfrxGetAncestorEvent)(const AnsiString ComponentName, Classes::TPersistent* &Ancestor);

class DELPHICLASS TfrxXMLSerializer;
class PASCALIMPLEMENTATION TfrxXMLSerializer : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TStringList* FErrors;
	Classes::TList* FFixups;
	Frxclass::TfrxComponent* FOwner;
	Classes::TReader* FReader;
	Classes::TMemoryStream* FReaderStream;
	bool FSerializeDefaultValues;
	Classes::TStream* FStream;
	TfrxGetAncestorEvent FOnGetAncestor;
	void __fastcall AddFixup(Classes::TPersistent* Obj, Typinfo::PPropInfo p, AnsiString Value);
	void __fastcall ClearFixups(void);
	void __fastcall FixupReferences(void);
	
public:
	__fastcall TfrxXMLSerializer(Classes::TStream* Stream);
	__fastcall virtual ~TfrxXMLSerializer(void);
	AnsiString __fastcall ObjToXML(Classes::TPersistent* Obj, const AnsiString Add = "", Classes::TPersistent* Ancestor = (Classes::TPersistent*)(0x0));
	Frxclass::TfrxComponent* __fastcall ReadComponent(Frxclass::TfrxComponent* Root);
	Frxclass::TfrxComponent* __fastcall ReadComponentStr(Frxclass::TfrxComponent* Root, AnsiString s, bool DontFixup = false);
	AnsiString __fastcall WriteComponentStr(Frxclass::TfrxComponent* c);
	void __fastcall ReadRootComponent(Frxclass::TfrxComponent* Root, Frxxml::TfrxXMLItem* XMLItem = (Frxxml::TfrxXMLItem*)(0x0));
	void __fastcall ReadPersistentStr(Classes::TComponent* Root, Classes::TPersistent* Obj, const AnsiString s);
	void __fastcall WriteComponent(Frxclass::TfrxComponent* c);
	void __fastcall WriteRootComponent(Frxclass::TfrxComponent* Root, bool SaveChildren = true, Frxxml::TfrxXMLItem* XMLItem = (Frxxml::TfrxXMLItem*)(0x0));
	void __fastcall XMLToObj(const AnsiString s, Classes::TPersistent* Obj);
	__property Classes::TStringList* Errors = {read=FErrors};
	__property Frxclass::TfrxComponent* Owner = {read=FOwner, write=FOwner};
	__property Classes::TStream* Stream = {read=FStream};
	__property bool SerializeDefaultValues = {read=FSerializeDefaultValues, write=FSerializeDefaultValues, nodefault};
	__property TfrxGetAncestorEvent OnGetAncestor = {read=FOnGetAncestor, write=FOnGetAncestor};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxxmlserializer */
using namespace Frxxmlserializer;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxxmlserializer
