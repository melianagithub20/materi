// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxdsgnintf.pas' rev: 10.00

#ifndef FrxdsgnintfHPP
#define FrxdsgnintfHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxdsgnintf
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxPropertyAttribute { paValueList, paSortList, paDialog, paMultiSelect, paSubProperties, paReadOnly, paOwnerDraw };
#pragma option pop

typedef Set<TfrxPropertyAttribute, paValueList, paOwnerDraw>  TfrxPropertyAttributes;

class DELPHICLASS TfrxPropertyEditor;
class PASCALIMPLEMENTATION TfrxPropertyEditor : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxclass::TfrxCustomDesigner* FDesigner;
	Classes::TList* FCompList;
	Classes::TList* FPropList;
	int FItemHeight;
	Classes::TStrings* FValues;
	Typinfo::PPropInfo __fastcall GetPropInfo(void);
	Classes::TPersistent* __fastcall GetComponent(void);
	Frxclass::TfrxComponent* __fastcall GetfrComponent(void);
	
protected:
	void __fastcall GetStrProc(const AnsiString s);
	Extended __fastcall GetFloatValue(void);
	int __fastcall GetOrdValue(void);
	AnsiString __fastcall GetStrValue();
	Variant __fastcall GetVarValue();
	void __fastcall SetFloatValue(Extended Value);
	void __fastcall SetOrdValue(int Value);
	void __fastcall SetStrValue(const AnsiString Value);
	void __fastcall SetVarValue(const Variant &Value);
	
public:
	__fastcall virtual TfrxPropertyEditor(Frxclass::TfrxCustomDesigner* Designer);
	__fastcall virtual ~TfrxPropertyEditor(void);
	virtual bool __fastcall Edit(void);
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetName();
	virtual int __fastcall GetExtraLBSize(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
	virtual void __fastcall OnDrawLBItem(Controls::TWinControl* Control, int Index, const Types::TRect &ARect, Windows::TOwnerDrawState State);
	virtual void __fastcall OnDrawItem(Graphics::TCanvas* Canvas, const Types::TRect &ARect);
	__property Classes::TPersistent* Component = {read=GetComponent};
	__property Frxclass::TfrxComponent* frComponent = {read=GetfrComponent};
	__property Frxclass::TfrxCustomDesigner* Designer = {read=FDesigner};
	__property int ItemHeight = {read=FItemHeight, write=FItemHeight, nodefault};
	__property Typinfo::PPropInfo PropInfo = {read=GetPropInfo};
	__property AnsiString Value = {read=GetValue, write=SetValue};
	__property Classes::TStrings* Values = {read=FValues};
};


typedef TMetaClass* TfrxPropertyEditorClass;

class DELPHICLASS TfrxComponentEditor;
class PASCALIMPLEMENTATION TfrxComponentEditor : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxclass::TfrxComponent* FComponent;
	Frxclass::TfrxCustomDesigner* FDesigner;
	Menus::TMenu* FMenu;
	
protected:
	Menus::TMenuItem* __fastcall AddItem(const AnsiString Caption, int Tag, bool Checked = false);
	
public:
	__fastcall TfrxComponentEditor(Frxclass::TfrxComponent* Component, Frxclass::TfrxCustomDesigner* Designer, Menus::TMenu* Menu);
	virtual bool __fastcall Edit(void);
	virtual bool __fastcall HasEditor(void);
	virtual void __fastcall GetMenuItems(void);
	virtual bool __fastcall Execute(int Tag, bool Checked);
	__property Frxclass::TfrxComponent* Component = {read=FComponent};
	__property Frxclass::TfrxCustomDesigner* Designer = {read=FDesigner};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxComponentEditor(void) { }
	#pragma option pop
	
};


typedef TMetaClass* TfrxComponentEditorClass;

class DELPHICLASS TfrxIntegerProperty;
class PASCALIMPLEMENTATION TfrxIntegerProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxIntegerProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxIntegerProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxFloatProperty;
class PASCALIMPLEMENTATION TfrxFloatProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxFloatProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxFloatProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCharProperty;
class PASCALIMPLEMENTATION TfrxCharProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxCharProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxCharProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxStringProperty;
class PASCALIMPLEMENTATION TfrxStringProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxStringProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxStringProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxEnumProperty;
class PASCALIMPLEMENTATION TfrxEnumProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxEnumProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxEnumProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxSetProperty;
class PASCALIMPLEMENTATION TfrxSetProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxSetProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxSetProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxSetElementProperty;
class PASCALIMPLEMENTATION TfrxSetElementProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
private:
	int FElement;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetName();
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxSetElementProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxSetElementProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxClassProperty;
class PASCALIMPLEMENTATION TfrxClassProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxClassProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxClassProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxComponentProperty;
class PASCALIMPLEMENTATION TfrxComponentProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxComponentProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxComponentProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxNameProperty;
class PASCALIMPLEMENTATION TfrxNameProperty : public TfrxStringProperty 
{
	typedef TfrxStringProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxNameProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxStringProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxColorProperty;
class PASCALIMPLEMENTATION TfrxColorProperty : public TfrxIntegerProperty 
{
	typedef TfrxIntegerProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual bool __fastcall Edit(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
	virtual void __fastcall OnDrawLBItem(Controls::TWinControl* Control, int Index, const Types::TRect &ARect, Windows::TOwnerDrawState State);
	virtual void __fastcall OnDrawItem(Graphics::TCanvas* Canvas, const Types::TRect &ARect);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxColorProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxIntegerProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxColorProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxFontProperty;
class PASCALIMPLEMENTATION TfrxFontProperty : public TfrxClassProperty 
{
	typedef TfrxClassProperty inherited;
	
public:
	virtual bool __fastcall Edit(void);
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxFontProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxClassProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxFontProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxFontNameProperty;
class PASCALIMPLEMENTATION TfrxFontNameProperty : public TfrxStringProperty 
{
	typedef TfrxStringProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual void __fastcall GetValues(void);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxFontNameProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxStringProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxFontNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxFontCharsetProperty;
class PASCALIMPLEMENTATION TfrxFontCharsetProperty : public TfrxIntegerProperty 
{
	typedef TfrxIntegerProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxFontCharsetProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxIntegerProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxFontCharsetProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxModalResultProperty;
class PASCALIMPLEMENTATION TfrxModalResultProperty : public TfrxIntegerProperty 
{
	typedef TfrxIntegerProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxModalResultProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxIntegerProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxModalResultProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxShortCutProperty;
class PASCALIMPLEMENTATION TfrxShortCutProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxShortCutProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxShortCutProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCursorProperty;
class PASCALIMPLEMENTATION TfrxCursorProperty : public TfrxIntegerProperty 
{
	typedef TfrxIntegerProperty inherited;
	
public:
	virtual TfrxPropertyAttributes __fastcall GetAttributes(void);
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall GetValues(void);
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxCursorProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxIntegerProperty(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxCursorProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDateTimeProperty;
class PASCALIMPLEMENTATION TfrxDateTimeProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxDateTimeProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxDateTimeProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDateProperty;
class PASCALIMPLEMENTATION TfrxDateProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxDateProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxDateProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxTimeProperty;
class PASCALIMPLEMENTATION TfrxTimeProperty : public TfrxPropertyEditor 
{
	typedef TfrxPropertyEditor inherited;
	
public:
	virtual AnsiString __fastcall GetValue();
	virtual void __fastcall SetValue(const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Create */ inline __fastcall virtual TfrxTimeProperty(Frxclass::TfrxCustomDesigner* Designer) : TfrxPropertyEditor(Designer) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxPropertyEditor.Destroy */ inline __fastcall virtual ~TfrxTimeProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPropertyItem;
class DELPHICLASS TfrxPropertyList;
class PASCALIMPLEMENTATION TfrxPropertyList : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxPropertyItem* operator[](int Index) { return Items[Index]; }
	
private:
	Classes::TPersistent* FComponent;
	Frxclass::TfrxCustomDesigner* FDesigner;
	TfrxPropertyList* FParent;
	void __fastcall AddProperties(TfrxPropertyList* PropertyList);
	void __fastcall FillProperties(Classes::TPersistent* AClass);
	void __fastcall FillCommonProperties(TfrxPropertyList* PropertyList);
	void __fastcall SetComponent(Classes::TPersistent* Value);
	TfrxPropertyItem* __fastcall GetPropertyItem(int Index);
	
public:
	__fastcall TfrxPropertyList(Frxclass::TfrxCustomDesigner* Designer);
	HIDESBASE TfrxPropertyItem* __fastcall Add(void);
	__property Classes::TPersistent* Component = {read=FComponent, write=SetComponent};
	__property TfrxPropertyItem* Items[int Index] = {read=GetPropertyItem/*, default*/};
	__property TfrxPropertyList* Parent = {read=FParent};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxPropertyList(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TfrxPropertyItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	TfrxPropertyEditor* FEditor;
	bool FExpanded;
	TfrxPropertyList* FSubProperty;
	
public:
	__fastcall virtual ~TfrxPropertyItem(void);
	__property TfrxPropertyEditor* Editor = {read=FEditor};
	__property bool Expanded = {read=FExpanded, write=FExpanded, nodefault};
	__property TfrxPropertyList* SubProperty = {read=FSubProperty};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxPropertyItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxObjectItem;
class PASCALIMPLEMENTATION TfrxObjectItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	TMetaClass* ClassRef;
	Graphics::TBitmap* ButtonBmp;
	int ButtonImageIndex;
	AnsiString ButtonHint;
	AnsiString CategoryName;
	Word Flags;
	bool IsDMPObject;
	bool IsReportObject;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxObjectItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxObjectItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxComponentEditorItem;
class PASCALIMPLEMENTATION TfrxComponentEditorItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	TMetaClass* ComponentClass;
	TMetaClass* ComponentEditor;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxComponentEditorItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxComponentEditorItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPropertyEditorItem;
class PASCALIMPLEMENTATION TfrxPropertyEditorItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	Typinfo::TTypeInfo *PropertyType;
	TMetaClass* ComponentClass;
	AnsiString PropertyName;
	TMetaClass* EditorClass;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxPropertyEditorItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxPropertyEditorItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxExportFilterItem;
class PASCALIMPLEMENTATION TfrxExportFilterItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	Frxclass::TfrxCustomExportFilter* Filter;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxExportFilterItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxExportFilterItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxWizardItem;
class PASCALIMPLEMENTATION TfrxWizardItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	TMetaClass* ClassRef;
	Graphics::TBitmap* ButtonBmp;
	int ButtonImageIndex;
	bool IsToolbarWizard;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxWizardItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxWizardItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxObjectCollection;
class PASCALIMPLEMENTATION TfrxObjectCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxObjectItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxObjectItem* __fastcall GetObjectItem(int Index);
	
public:
	__fastcall TfrxObjectCollection(void);
	void __fastcall RegisterCategory(const AnsiString CategoryName, Graphics::TBitmap* ButtonBmp, const AnsiString ButtonHint, int ImageIndex = 0xffffffff);
	void __fastcall RegisterObject(TMetaClass* ClassRef, Graphics::TBitmap* ButtonBmp, const AnsiString CategoryName = "");
	void __fastcall RegisterObject1(TMetaClass* ClassRef, Graphics::TBitmap* ButtonBmp, const AnsiString ButtonHint = "", const AnsiString CategoryName = "", int Flags = 0x0, int ImageIndex = 0xffffffff, bool IsReport = true, bool IsDMP = false);
	void __fastcall Unregister(TMetaClass* ClassRef);
	__property TfrxObjectItem* Items[int Index] = {read=GetObjectItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxObjectCollection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxComponentEditorCollection;
class PASCALIMPLEMENTATION TfrxComponentEditorCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxComponentEditorItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxComponentEditorItem* __fastcall GetComponentEditorItem(int Index);
	
public:
	__fastcall TfrxComponentEditorCollection(void);
	void __fastcall Register(TMetaClass* ComponentClass, TMetaClass* ComponentEditor);
	TfrxComponentEditor* __fastcall GetComponentEditor(Frxclass::TfrxComponent* Component, Frxclass::TfrxCustomDesigner* Designer, Menus::TMenu* Menu);
	__property TfrxComponentEditorItem* Items[int Index] = {read=GetComponentEditorItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxComponentEditorCollection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPropertyEditorCollection;
class PASCALIMPLEMENTATION TfrxPropertyEditorCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxPropertyEditorItem* operator[](int Index) { return Items[Index]; }
	
private:
	int FEventEditorItem;
	TfrxPropertyEditorItem* __fastcall GetPropertyEditorItem(int Index);
	
public:
	__fastcall TfrxPropertyEditorCollection(void);
	void __fastcall Register(Typinfo::PTypeInfo PropertyType, TMetaClass* ComponentClass, const AnsiString PropertyName, TMetaClass* EditorClass);
	void __fastcall RegisterEventEditor(TMetaClass* EditorClass);
	int __fastcall GetPropertyEditor(Typinfo::PTypeInfo PropertyType, Classes::TPersistent* Component, AnsiString PropertyName);
	__property TfrxPropertyEditorItem* Items[int Index] = {read=GetPropertyEditorItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxPropertyEditorCollection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxExportFilterCollection;
class PASCALIMPLEMENTATION TfrxExportFilterCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxExportFilterItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxExportFilterItem* __fastcall GetExportFilterItem(int Index);
	
public:
	__fastcall TfrxExportFilterCollection(void);
	void __fastcall Register(Frxclass::TfrxCustomExportFilter* Filter);
	void __fastcall Unregister(Frxclass::TfrxCustomExportFilter* Filter);
	__property TfrxExportFilterItem* Items[int Index] = {read=GetExportFilterItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxExportFilterCollection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxWizardCollection;
class PASCALIMPLEMENTATION TfrxWizardCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxWizardItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxWizardItem* __fastcall GetWizardItem(int Index);
	
public:
	__fastcall TfrxWizardCollection(void);
	void __fastcall Register(TMetaClass* ClassRef, Graphics::TBitmap* ButtonBmp, bool IsToolbarWizard = false);
	void __fastcall Register1(TMetaClass* ClassRef, int ImageIndex);
	void __fastcall Unregister(TMetaClass* ClassRef);
	__property TfrxWizardItem* Items[int Index] = {read=GetWizardItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxWizardCollection(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxHideProperties(TMetaClass* ComponentClass, const AnsiString Properties);
extern PACKAGE TfrxPropertyList* __fastcall frxCreatePropertyList(Classes::TList* ComponentList, Frxclass::TfrxCustomDesigner* Designer);
extern PACKAGE TfrxObjectCollection* __fastcall frxObjects(void);
extern PACKAGE TfrxComponentEditorCollection* __fastcall frxComponentEditors(void);
extern PACKAGE TfrxPropertyEditorCollection* __fastcall frxPropertyEditors(void);
extern PACKAGE TfrxExportFilterCollection* __fastcall frxExportFilters(void);
extern PACKAGE TfrxWizardCollection* __fastcall frxWizards(void);

}	/* namespace Frxdsgnintf */
using namespace Frxdsgnintf;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxdsgnintf
