// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Rc_algref.pas' rev: 10.00

#ifndef Rc_algrefHPP
#define Rc_algrefHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rc_algref
{
//-- type declarations -------------------------------------------------------
typedef Byte word8;

typedef Word word16;

typedef unsigned word32;

typedef Byte TArrayK[4][8];

typedef TArrayK *PArrayK;

typedef Byte TArrayRK[15][4][8];

typedef Byte TArrayBox[256];

//-- var, const, procedure ---------------------------------------------------
static const Shortint MAXBC = 0x8;
static const Shortint MAXKC = 0x8;
static const Shortint MAXROUNDS = 0xe;
extern PACKAGE int __fastcall rijndaelKeySched( * k, int keyBits, int blockBits,  * W);
extern PACKAGE int __fastcall rijndaelEncrypt( * a, int keyBits, int blockBits,  * rk);
extern PACKAGE int __fastcall rijndaelEncryptRound( * a, int keyBits, int blockBits,  * rk, int &irounds);
extern PACKAGE int __fastcall rijndaelDecrypt( * a, int keyBits, int blockBits,  * rk);
extern PACKAGE int __fastcall rijndaelDecryptRound( * a, int keyBits, int blockBits,  * rk, int &irounds);

}	/* namespace Rc_algref */
using namespace Rc_algref;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Rc_algref
