// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxutils.pas' rev: 10.00

#ifndef FrxutilsHPP
#define FrxutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Imglist.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE unsigned __fastcall frxStreamCRC32(Classes::TStream* Stream);
extern PACKAGE Classes::TComponent* __fastcall frxFindComponent(Classes::TComponent* Owner, const AnsiString Name);
extern PACKAGE void __fastcall frxGetComponents(Classes::TComponent* Owner, TMetaClass* ClassRef, Classes::TStrings* List, Classes::TComponent* Skip);
extern PACKAGE AnsiString __fastcall frxGetFullName(Classes::TComponent* Owner, Classes::TComponent* c);
extern PACKAGE void __fastcall frxSetCommaText(const AnsiString Text, Classes::TStrings* sl, char Comma = '\x3b');
extern PACKAGE AnsiString __fastcall frxRemoveQuotes(const AnsiString s);
extern PACKAGE AnsiString __fastcall frxStreamToString(Classes::TStream* Stream);
extern PACKAGE void __fastcall frxStringToStream(const AnsiString s, Classes::TStream* Stream);
extern PACKAGE Extended __fastcall frxStrToFloat(AnsiString s);
extern PACKAGE AnsiString __fastcall frxFloatToStr(Extended d);
extern PACKAGE Frxclass::TfrxRect __fastcall frxRect(Extended ALeft, Extended ATop, Extended ARight, Extended ABottom);
extern PACKAGE Frxclass::TfrxPoint __fastcall frxPoint(Extended X, Extended Y);
extern PACKAGE AnsiString __fastcall frxGetBrackedVariable(const AnsiString Str, const AnsiString OpenBracket, const AnsiString CloseBracket, int &i, int &j);
extern PACKAGE WideString __fastcall frxGetBrackedVariableW(const WideString Str, const WideString OpenBracket, const WideString CloseBracket, int &i, int &j);
extern PACKAGE void __fastcall frxCommonErrorHandler(Frxclass::TfrxReport* Report, const AnsiString Text);
extern PACKAGE void __fastcall frxErrorMsg(const AnsiString Text);
extern PACKAGE int __fastcall frxConfirmMsg(const AnsiString Text, int Buttons);
extern PACKAGE void __fastcall frxInfoMsg(const AnsiString Text);
extern PACKAGE bool __fastcall frxIsValidFloat(const AnsiString Value);
extern PACKAGE void __fastcall frxAssignImages(Graphics::TBitmap* Bitmap, int dx, int dy, Controls::TImageList* ImgList1, Controls::TImageList* ImgList2 = (Controls::TImageList*)(0x0));
extern PACKAGE void __fastcall frxDrawTransparent(Graphics::TCanvas* Canvas, int x, int y, Graphics::TBitmap* bmp);
extern PACKAGE void __fastcall frxDrawGraphic(Graphics::TCanvas* Canvas, const Types::TRect &DestRect, Graphics::TGraphic* aGraph, bool IsPrinting);
extern PACKAGE void __fastcall frxParsePageNumbers(const AnsiString PageNumbers, Classes::TStrings* List, int Total);
extern PACKAGE AnsiString __fastcall HTMLRGBColor(Graphics::TColor Color);
extern PACKAGE void __fastcall frxWriteCollection(Classes::TCollection* Collection, Classes::TWriter* Writer, Frxclass::TfrxComponent* Owner);
extern PACKAGE void __fastcall frxReadCollection(Classes::TCollection* Collection, Classes::TReader* Reader, Frxclass::TfrxComponent* Owner);
extern PACKAGE AnsiString __fastcall GetTemporaryFolder();
extern PACKAGE AnsiString __fastcall GetTempFile();
extern PACKAGE AnsiString __fastcall frxCreateTempFile(const AnsiString TempDir);
extern PACKAGE AnsiString __fastcall GetAppFileName();
extern PACKAGE AnsiString __fastcall GetAppPath();
extern PACKAGE AnsiString __fastcall frFloat2Str(const Extended Value, const int Prec = 0x2);
extern PACKAGE AnsiString __fastcall frxReverseString(const AnsiString AText);

}	/* namespace Frxutils */
using namespace Frxutils;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxutils
