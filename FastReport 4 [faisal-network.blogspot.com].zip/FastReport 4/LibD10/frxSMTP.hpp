// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxsmtp.pas' rev: 10.00

#ifndef FrxsmtpHPP
#define FrxsmtpHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Scktcomp.hpp>	// Pascal unit
#include <Frxnetutils.hpp>	// Pascal unit
#include <Frxprogress.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxsmtp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSMTPClient;
class DELPHICLASS TfrxSMTPClientThread;
class PASCALIMPLEMENTATION TfrxSMTPClientThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
protected:
	TfrxSMTPClient* FClient;
	void __fastcall DoOpen(void);
	virtual void __fastcall Execute(void);
	
public:
	Scktcomp::TClientSocket* FSocket;
	__fastcall TfrxSMTPClientThread(TfrxSMTPClient* Client);
	__fastcall virtual ~TfrxSMTPClientThread(void);
};


class PASCALIMPLEMENTATION TfrxSMTPClient : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	bool FBreaked;
	Classes::TStrings* FErrors;
	AnsiString FHost;
	int FPort;
	TfrxSMTPClientThread* FThread;
	int FTimeOut;
	AnsiString FPassword;
	AnsiString FMailTo;
	AnsiString FUser;
	AnsiString FMailFile;
	AnsiString FMailFrom;
	AnsiString FMailSubject;
	AnsiString FMailText;
	AnsiString FAnswer;
	bool FAccepted;
	AnsiString FAuth;
	int FCode;
	bool FSending;
	AnsiString FAttachName;
	Frxprogress::TfrxProgress* FProgress;
	bool FShowProgress;
	AnsiString FLogFile;
	Classes::TStringList* FLog;
	Classes::TStringList* FAnswerList;
	bool F200Flag;
	bool F210Flag;
	bool F215Flag;
	AnsiString FUserName;
	void __fastcall DoConnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoDisconnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoError(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket, Scktcomp::TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall DoRead(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall SetActive(const bool Value);
	void __fastcall AddLogIn(const AnsiString s);
	void __fastcall AddLogOut(const AnsiString s);
	AnsiString __fastcall DomainByEmail(const AnsiString addr);
	
public:
	__fastcall virtual TfrxSMTPClient(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxSMTPClient(void);
	void __fastcall Connect(void);
	void __fastcall Disconnect(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	__property bool Breaked = {read=FBreaked, nodefault};
	__property Classes::TStrings* Errors = {read=FErrors, write=FErrors};
	__property AnsiString LogFile = {read=FLogFile, write=FLogFile};
	
__published:
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property AnsiString UserName = {read=FUserName, write=FUserName};
	__property AnsiString User = {read=FUser, write=FUser};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString MailFrom = {read=FMailFrom, write=FMailFrom};
	__property AnsiString MailTo = {read=FMailTo, write=FMailTo};
	__property AnsiString MailSubject = {read=FMailSubject, write=FMailSubject};
	__property AnsiString MailText = {read=FMailText, write=FMailText};
	__property AnsiString MailFile = {read=FMailFile, write=FMailFile};
	__property AnsiString AttachName = {read=FAttachName, write=FAttachName};
	__property bool ShowProgress = {read=FShowProgress, write=FShowProgress, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxsmtp */
using namespace Frxsmtp;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxsmtp
