// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxpdffile.pas' rev: 10.00

#ifndef FrxpdffileHPP
#define FrxpdffileHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Frxutils.hpp>	// Pascal unit
#include <Jpeg.hpp>	// Pascal unit
#include <Frxunicodeutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxpdffile
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxPDFElement;
class PASCALIMPLEMENTATION TfrxPDFElement : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	unsigned FXrefPosition;
	int FIndex;
	AnsiString FLines;
	bool FCR;
	void __fastcall Write(const AnsiString S);
	void __fastcall WriteLn(const AnsiString S);
	void __fastcall Flush(const Classes::TStream* Stream);
	
public:
	__fastcall TfrxPDFElement(void);
	virtual void __fastcall SaveToStream(const Classes::TStream* Stream);
	
__published:
	__property unsigned XrefPosition = {read=FXrefPosition, nodefault};
	__property int Index = {read=FIndex, write=FIndex, nodefault};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxPDFElement(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPDFToolkit;
class PASCALIMPLEMENTATION TfrxPDFToolkit : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	Extended Divider;
	Extended LineHeight;
	Graphics::TColor LastColor;
	AnsiString LastColorResult;
	__fastcall TfrxPDFToolkit(void);
	Extended __fastcall GetHTextPos(const Extended Left, const Extended Width, const Extended CharSpacing, const AnsiString Text, const Frxclass::TfrxHAlign Align);
	Extended __fastcall GetVTextPos(const Extended Top, const Extended Height, const AnsiString Text, const Frxclass::TfrxVAlign Align, const int Line = 0x0, const int Count = 0x1);
	Extended __fastcall GetLineWidth(const AnsiString Text, const Extended CharSpacing);
	void __fastcall SetMemo(const Frxclass::TfrxCustomMemoView* Memo);
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxPDFToolkit(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPDFFile;
class DELPHICLASS TfrxPDFPage;
class PASCALIMPLEMENTATION TfrxPDFFile : public TfrxPDFElement 
{
	typedef TfrxPDFElement inherited;
	
private:
	Classes::TList* FPages;
	Classes::TList* FFonts;
	Classes::TStringList* FXRef;
	int FObjNo;
	int FCounter;
	AnsiString FTitle;
	unsigned FStartXRef;
	int FStartFonts;
	int FStartPages;
	int FPagesRoot;
	bool FCompressed;
	bool FPrintOpt;
	bool FOutline;
	Frxclass::TfrxCustomOutline* FPreviewOutline;
	AnsiString FSubject;
	AnsiString FAuthor;
	bool FBackground;
	AnsiString FCreator;
	bool FHTMLTags;
	
public:
	Classes::TStream* FStreamObjects;
	AnsiString FTempStreamFile;
	bool FEmbedded;
	int FFontDCnt;
	TfrxPDFToolkit* PTool;
	__fastcall TfrxPDFFile(const bool UseFileCache, const AnsiString TempDir);
	__fastcall virtual ~TfrxPDFFile(void);
	void __fastcall Clear(void);
	void __fastcall XRefAdd(Classes::TStream* Stream, int ObjNo);
	virtual void __fastcall SaveToStream(const Classes::TStream* Stream);
	TfrxPDFPage* __fastcall AddPage(const Frxclass::TfrxReportPage* Page);
	int __fastcall AddFont(const Graphics::TFont* Font);
	
__published:
	__property Classes::TList* Pages = {read=FPages};
	__property Classes::TList* Fonts = {read=FFonts};
	__property int Counter = {read=FCounter, write=FCounter, nodefault};
	__property AnsiString Title = {read=FTitle, write=FTitle};
	__property bool Compressed = {read=FCompressed, write=FCompressed, nodefault};
	__property bool EmbeddedFonts = {read=FEmbedded, write=FEmbedded, default=1};
	__property bool PrintOptimized = {read=FPrintOpt, write=FPrintOpt, nodefault};
	__property bool Outline = {read=FOutline, write=FOutline, nodefault};
	__property Frxclass::TfrxCustomOutline* PreviewOutline = {read=FPreviewOutline, write=FPreviewOutline};
	__property AnsiString Author = {read=FAuthor, write=FAuthor};
	__property AnsiString Subject = {read=FSubject, write=FSubject};
	__property bool Background = {read=FBackground, write=FBackground, nodefault};
	__property AnsiString Creator = {read=FCreator, write=FCreator};
	__property bool HTMLTags = {read=FHTMLTags, write=FHTMLTags, nodefault};
};


class PASCALIMPLEMENTATION TfrxPDFPage : public TfrxPDFElement 
{
	typedef TfrxPDFElement inherited;
	
private:
	int FStreamOffset;
	TfrxPDFFile* FParent;
	Extended FWidth;
	Extended FHeight;
	Extended FMarginLeft;
	Extended FMarginTop;
	Classes::TStream* FStream;
	int FStreamSize;
	
public:
	__fastcall TfrxPDFPage(void);
	virtual void __fastcall SaveToStream(const Classes::TStream* Stream);
	void __fastcall AddObject(const Frxclass::TfrxView* Obj);
	__property int StreamOffset = {read=FStreamOffset, write=FStreamOffset, nodefault};
	__property int StreamSize = {read=FStreamSize, write=FStreamSize, nodefault};
	
__published:
	__property Classes::TStream* OutStream = {read=FStream, write=FStream};
	__property TfrxPDFFile* Parent = {read=FParent, write=FParent};
	__property Extended Width = {read=FWidth, write=FWidth};
	__property Extended Height = {read=FHeight, write=FHeight};
	__property Extended MarginLeft = {read=FMarginLeft, write=FMarginLeft};
	__property Extended MarginTop = {read=FMarginTop, write=FMarginTop};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxPDFPage(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPDFFont;
class PASCALIMPLEMENTATION TfrxPDFFont : public TfrxPDFElement 
{
	typedef TfrxPDFElement inherited;
	
private:
	Graphics::TFont* FFont;
	TfrxPDFFile* FParent;
	int FFontDCnt;
	
public:
	__fastcall TfrxPDFFont(void);
	__fastcall virtual ~TfrxPDFFont(void);
	virtual void __fastcall SaveToStream(const Classes::TStream* Stream);
	
__published:
	__property TfrxPDFFile* Parent = {read=FParent, write=FParent};
	__property Graphics::TFont* Font = {read=FFont};
};


class DELPHICLASS TfrxPDFOutlineNode;
class PASCALIMPLEMENTATION TfrxPDFOutlineNode : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	AnsiString Title;
	int Dest;
	int Top;
	int Number;
	int CountTree;
	int Count;
	TfrxPDFOutlineNode* First;
	TfrxPDFOutlineNode* Last;
	TfrxPDFOutlineNode* Parent;
	TfrxPDFOutlineNode* Prev;
	TfrxPDFOutlineNode* Next;
	__fastcall TfrxPDFOutlineNode(void);
	__fastcall virtual ~TfrxPDFOutlineNode(void);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxpdffile */
using namespace Frxpdffile;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxpdffile
