// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxcross.pas' rev: 10.00

#ifndef FrxcrossHPP
#define FrxcrossHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcross
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxCrossObject;
class PASCALIMPLEMENTATION TfrxCrossObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxCrossObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxCrossObject(void) { }
	#pragma option pop
	
};


typedef AnsiString TfrxPrintCellEvent;

typedef AnsiString TfrxPrintHeaderEvent;

typedef AnsiString TfrxCalcWidthEvent;

typedef AnsiString TfrxCalcHeightEvent;

typedef void __fastcall (__closure *TfrxOnPrintCellEvent)(Frxclass::TfrxCustomMemoView* Memo, int RowIndex, int ColumnIndex, int CellIndex, const Variant &RowValues, const Variant &ColumnValues, const Variant &Value);

typedef void __fastcall (__closure *TfrxOnPrintHeaderEvent)(Frxclass::TfrxCustomMemoView* Memo, const Variant &HeaderIndexes, const Variant &HeaderValues, const Variant &Value);

typedef void __fastcall (__closure *TfrxOnCalcWidthEvent)(int ColumnIndex, const Variant &ColumnValues, Extended &Width);

typedef void __fastcall (__closure *TfrxOnCalcHeightEvent)(int RowIndex, const Variant &RowValues, Extended &Height);

struct TfrxCrossCell;
typedef TfrxCrossCell *PfrCrossCell;

#pragma pack(push,1)
struct TfrxCrossCell
{
	
public:
	Variant Value;
	int Count;
	TfrxCrossCell *Next;
} ;
#pragma pack(pop)

#pragma option push -b-
enum TfrxCrossSortOrder { soAscending, soDescending, soNone };
#pragma option pop

#pragma option push -b-
enum TfrxCrossFunction { cfNone, cfSum, cfMin, cfMax, cfAvg, cfCount };
#pragma option pop

typedef DynamicArray<Variant >  TfrxVariantArray;

typedef TfrxCrossSortOrder TfrxSortArray[32];

class DELPHICLASS TfrxIndexItem;
class PASCALIMPLEMENTATION TfrxIndexItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	DynamicArray<Variant >  FIndexes;
	
public:
	__fastcall virtual ~TfrxIndexItem(void);
	__property TfrxVariantArray Indexes = {read=FIndexes, write=FIndexes};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxIndexItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxIndexCollection;
class PASCALIMPLEMENTATION TfrxIndexCollection : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxIndexItem* operator[](int Index) { return Items[Index]; }
	
private:
	int FIndexesCount;
	TfrxCrossSortOrder FSortOrder[32];
	TfrxIndexItem* __fastcall GetItems(int Index);
	
public:
	bool __fastcall Find(Variant const * Indexes, const int Indexes_Size, int &Index);
	HIDESBASE virtual TfrxIndexItem* __fastcall InsertItem(int Index, Variant const * Indexes, const int Indexes_Size);
	__property TfrxIndexItem* Items[int Index] = {read=GetItems/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Create */ inline __fastcall TfrxIndexCollection(TMetaClass* ItemClass) : Classes::TCollection(ItemClass) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxIndexCollection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossRow;
class PASCALIMPLEMENTATION TfrxCrossRow : public TfrxIndexItem 
{
	typedef TfrxIndexItem inherited;
	
private:
	int FCellLevels;
	Classes::TList* FCells;
	void __fastcall CreateCell(int Index);
	
public:
	__fastcall virtual TfrxCrossRow(Classes::TCollection* Collection);
	__fastcall virtual ~TfrxCrossRow(void);
	PfrCrossCell __fastcall GetCell(int Index);
	Variant __fastcall GetCellValue(int Index1, int Index2);
	void __fastcall SetCellValue(int Index1, int Index2, const Variant &Value);
};


class DELPHICLASS TfrxCrossRows;
class PASCALIMPLEMENTATION TfrxCrossRows : public TfrxIndexCollection 
{
	typedef TfrxIndexCollection inherited;
	
public:
	TfrxCrossRow* operator[](int Index) { return Items[Index]; }
	
private:
	int FCellLevels;
	HIDESBASE TfrxCrossRow* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxCrossRows(void);
	virtual TfrxIndexItem* __fastcall InsertItem(int Index, Variant const * Indexes, const int Indexes_Size);
	TfrxCrossRow* __fastcall Row(Variant const * Indexes, const int Indexes_Size);
	__property TfrxCrossRow* Items[int Index] = {read=GetItems/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxCrossRows(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossColumn;
class PASCALIMPLEMENTATION TfrxCrossColumn : public TfrxIndexItem 
{
	typedef TfrxIndexItem inherited;
	
private:
	int FCellIndex;
	
public:
	__property int CellIndex = {read=FCellIndex, write=FCellIndex, nodefault};
public:
	#pragma option push -w-inl
	/* TfrxIndexItem.Destroy */ inline __fastcall virtual ~TfrxCrossColumn(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxCrossColumn(Classes::TCollection* Collection) : TfrxIndexItem(Collection) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossColumns;
class PASCALIMPLEMENTATION TfrxCrossColumns : public TfrxIndexCollection 
{
	typedef TfrxIndexCollection inherited;
	
public:
	TfrxCrossColumn* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TfrxCrossColumn* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxCrossColumns(void);
	TfrxCrossColumn* __fastcall Column(Variant const * Indexes, const int Indexes_Size);
	virtual TfrxIndexItem* __fastcall InsertItem(int Index, Variant const * Indexes, const int Indexes_Size);
	__property TfrxCrossColumn* Items[int Index] = {read=GetItems/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxCrossColumns(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossHeader;
class PASCALIMPLEMENTATION TfrxCrossHeader : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxCrossHeader* operator[](int Index) { return Items[Index]; }
	
private:
	#pragma pack(push,1)
	Frxclass::TfrxRect FBounds;
	#pragma pack(pop)
	Classes::TList* FMemos;
	Classes::TList* FTotalMemos;
	DynamicArray<Variant >  FCounts;
	int FCellIndex;
	int FCellLevels;
	DynamicArray<Variant >  FFuncValues;
	bool FHasCellHeaders;
	int FIndex;
	bool FIsCellHeader;
	bool FIsIndex;
	bool FIsTotal;
	Classes::TList* FItems;
	int FLevelsCount;
	Frxclass::TfrxCustomMemoView* FMemo;
	bool FNoLevels;
	TfrxCrossHeader* FParent;
	#pragma pack(push,1)
	Frxclass::TfrxPoint FSize;
	#pragma pack(pop)
	int FTotalIndex;
	Variant FValue;
	bool FVisible;
	TfrxCrossHeader* __fastcall AddCellHeader(Classes::TList* Memos, int Index, int CellIndex);
	TfrxCrossHeader* __fastcall AddChild(Frxclass::TfrxCustomMemoView* Memo);
	void __fastcall AddFuncValues(Variant const * Values, const int Values_Size, Variant const * Counts, const int Counts_Size, TfrxCrossFunction const * CellFunctions, const int CellFunctions_Size);
	void __fastcall AddValues(Variant const * Values, const int Values_Size);
	void __fastcall Reset(TfrxCrossFunction const * CellFunctions, const int CellFunctions_Size);
	int __fastcall GetCount(void);
	TfrxCrossHeader* __fastcall GetItems(int Index);
	int __fastcall GetLevel(void);
	Extended __fastcall GetHeight(void);
	Extended __fastcall GetWidth(void);
	
public:
	__fastcall TfrxCrossHeader(int CellLevels);
	__fastcall virtual ~TfrxCrossHeader(void);
	virtual void __fastcall CalcBounds(void) = 0 ;
	virtual void __fastcall CalcSizes(int MaxWidth, int MinWidth, bool AutoSize) = 0 ;
	Classes::TList* __fastcall AllItems(void);
	int __fastcall Find(const Variant &Value);
	Variant __fastcall GetIndexes();
	Variant __fastcall GetValues();
	Classes::TList* __fastcall TerminalItems(void);
	Classes::TList* __fastcall IndexItems(void);
	__property Frxclass::TfrxRect Bounds = {read=FBounds, write=FBounds};
	__property int Count = {read=GetCount, nodefault};
	__property bool HasCellHeaders = {read=FHasCellHeaders, write=FHasCellHeaders, nodefault};
	__property Extended Height = {read=GetHeight};
	__property bool IsTotal = {read=FIsTotal, nodefault};
	__property TfrxCrossHeader* Items[int Index] = {read=GetItems/*, default*/};
	__property int Level = {read=GetLevel, nodefault};
	__property Frxclass::TfrxCustomMemoView* Memo = {read=FMemo};
	__property TfrxCrossHeader* Parent = {read=FParent};
	__property Variant Value = {read=FValue, write=FValue};
	__property bool Visible = {read=FVisible, write=FVisible, nodefault};
	__property Extended Width = {read=GetWidth};
};


class DELPHICLASS TfrxCrossColumnHeader;
class PASCALIMPLEMENTATION TfrxCrossColumnHeader : public TfrxCrossHeader 
{
	typedef TfrxCrossHeader inherited;
	
private:
	TfrxCrossHeader* FCorner;
	
public:
	virtual void __fastcall CalcBounds(void);
	virtual void __fastcall CalcSizes(int MaxWidth, int MinWidth, bool AutoSize);
public:
	#pragma option push -w-inl
	/* TfrxCrossHeader.Create */ inline __fastcall TfrxCrossColumnHeader(int CellLevels) : TfrxCrossHeader(CellLevels) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCrossHeader.Destroy */ inline __fastcall virtual ~TfrxCrossColumnHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossRowHeader;
class PASCALIMPLEMENTATION TfrxCrossRowHeader : public TfrxCrossHeader 
{
	typedef TfrxCrossHeader inherited;
	
private:
	TfrxCrossHeader* FCorner;
	
public:
	virtual void __fastcall CalcBounds(void);
	virtual void __fastcall CalcSizes(int MaxWidth, int MinWidth, bool AutoSize);
public:
	#pragma option push -w-inl
	/* TfrxCrossHeader.Create */ inline __fastcall TfrxCrossRowHeader(int CellLevels) : TfrxCrossHeader(CellLevels) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCrossHeader.Destroy */ inline __fastcall virtual ~TfrxCrossRowHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossCorner;
class PASCALIMPLEMENTATION TfrxCrossCorner : public TfrxCrossColumnHeader 
{
	typedef TfrxCrossColumnHeader inherited;
	
public:
	#pragma option push -w-inl
	/* TfrxCrossHeader.Create */ inline __fastcall TfrxCrossCorner(int CellLevels) : TfrxCrossColumnHeader(CellLevels) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCrossHeader.Destroy */ inline __fastcall virtual ~TfrxCrossCorner(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCutBandItem;
class PASCALIMPLEMENTATION TfrxCutBandItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	Frxclass::TfrxBand* Band;
	int FromIndex;
	int ToIndex;
	__fastcall virtual ~TfrxCutBandItem(void);
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxCutBandItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCutBands;
class PASCALIMPLEMENTATION TfrxCutBands : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxCutBandItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxCutBandItem* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxCutBands(void);
	HIDESBASE void __fastcall Add(Frxclass::TfrxBand* ABand, int AFromIndex, int AToIndex);
	__property TfrxCutBandItem* Items[int Index] = {read=GetItems/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxCutBands(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxGridLineItem;
class PASCALIMPLEMENTATION TfrxGridLineItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	Extended Coord;
	Classes::TList* Objects;
	__fastcall virtual TfrxGridLineItem(Classes::TCollection* Collection);
	__fastcall virtual ~TfrxGridLineItem(void);
};


class DELPHICLASS TfrxGridLines;
class PASCALIMPLEMENTATION TfrxGridLines : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxGridLineItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxGridLineItem* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxGridLines(void);
	HIDESBASE void __fastcall Add(System::TObject* AObj, Extended ACoord);
	__property TfrxGridLineItem* Items[int Index] = {read=GetItems/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxGridLines(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCustomCrossView;
class PASCALIMPLEMENTATION TfrxCustomCrossView : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	Extended FAddHeight;
	Extended FAddWidth;
	bool FAllowDuplicates;
	bool FAutoSize;
	bool FBorder;
	Classes::TStrings* FCellFields;
	TfrxCrossFunction FCellFunctions[32];
	int FCellLevels;
	bool FClearBeforePrint;
	TfrxCutBands* FColumnBands;
	Classes::TStrings* FColumnFields;
	TfrxCrossColumnHeader* FColumnHeader;
	int FColumnLevels;
	TfrxCrossColumns* FColumns;
	TfrxCrossSortOrder FColumnSort[32];
	TfrxCrossCorner* FCorner;
	int FDefHeight;
	bool FDotMatrix;
	bool FDownThenAcross;
	#pragma pack(push,1)
	Types::TPoint FFirstMousePos;
	#pragma pack(pop)
	int FGapX;
	int FGapY;
	TfrxGridLines* FGridUsed;
	TfrxGridLines* FGridX;
	TfrxGridLines* FGridY;
	bool FJoinEqualCells;
	#pragma pack(push,1)
	Types::TPoint FLastMousePos;
	#pragma pack(pop)
	int FMaxWidth;
	int FMinWidth;
	bool FMouseDown;
	int FMovingObjects;
	TfrxCustomCrossView* FNextCross;
	Extended FNextCrossGap;
	bool FNoColumns;
	bool FNoRows;
	bool FPlainCells;
	bool FRepeatHeaders;
	TfrxCutBands* FRowBands;
	Classes::TStrings* FRowFields;
	TfrxCrossRowHeader* FRowHeader;
	int FRowLevels;
	TfrxCrossRows* FRows;
	TfrxCrossSortOrder FRowSort[32];
	bool FShowColumnHeader;
	bool FShowColumnTotal;
	bool FShowCorner;
	bool FShowRowHeader;
	bool FShowRowTotal;
	bool FShowTitle;
	bool FSuppressNullRecords;
	Classes::TList* FAllMemos;
	Classes::TList* FCellMemos;
	Classes::TList* FCellHeaderMemos;
	Classes::TList* FColumnMemos;
	Classes::TList* FColumnTotalMemos;
	Classes::TList* FCornerMemos;
	Classes::TList* FRowMemos;
	Classes::TList* FRowTotalMemos;
	AnsiString FOnCalcHeight;
	AnsiString FOnCalcWidth;
	AnsiString FOnPrintCell;
	AnsiString FOnPrintColumnHeader;
	AnsiString FOnPrintRowHeader;
	TfrxOnCalcHeightEvent FOnBeforeCalcHeight;
	TfrxOnCalcWidthEvent FOnBeforeCalcWidth;
	TfrxOnPrintCellEvent FOnBeforePrintCell;
	TfrxOnPrintHeaderEvent FOnBeforePrintColumnHeader;
	TfrxOnPrintHeaderEvent FOnBeforePrintRowHeader;
	void __fastcall CalcBounds(Extended addWidth, Extended addHeight);
	void __fastcall CalcTotal(TfrxCrossHeader* Header, TfrxIndexCollection* Source);
	void __fastcall CalcTotals(void);
	void __fastcall CreateHeader(TfrxCrossHeader* Header, TfrxIndexCollection* Source, Classes::TList* Totals, bool TotalVisible);
	void __fastcall CreateHeaders(void);
	void __fastcall AddSourceObjects(void);
	void __fastcall BuildColumnBands(void);
	void __fastcall BuildRowBands(void);
	void __fastcall ClearMatrix(void);
	void __fastcall ClearMemos(void);
	void __fastcall CreateCellHeaderMemos(int NewCount);
	void __fastcall CreateCellMemos(int NewCount);
	void __fastcall CreateColumnMemos(int NewCount);
	void __fastcall CreateCornerMemos(int NewCount);
	void __fastcall CreateRowMemos(int NewCount);
	void __fastcall CorrectDMPBounds(Frxclass::TfrxCustomMemoView* Memo);
	void __fastcall DoCalcHeight(int Row, Extended &Height);
	void __fastcall DoCalcWidth(int Column, Extended &Width);
	void __fastcall DoOnCell(Frxclass::TfrxCustomMemoView* Memo, int Row, int Column, int Cell, const Variant &Value);
	void __fastcall DoOnColumnHeader(Frxclass::TfrxCustomMemoView* Memo, TfrxCrossHeader* Header);
	void __fastcall DoOnRowHeader(Frxclass::TfrxCustomMemoView* Memo, TfrxCrossHeader* Header);
	void __fastcall InitMatrix(void);
	void __fastcall InitMemos(bool AddToScript);
	void __fastcall ReadMemos(Classes::TStream* Stream);
	void __fastcall RenderMatrix(void);
	void __fastcall SetCellFields(const Classes::TStrings* Value);
	void __fastcall SetCellFunctions(int Index, const TfrxCrossFunction Value);
	void __fastcall SetColumnFields(const Classes::TStrings* Value);
	void __fastcall SetColumnSort(int Index, TfrxCrossSortOrder Value);
	void __fastcall SetDotMatrix(const bool Value);
	void __fastcall SetRowFields(const Classes::TStrings* Value);
	void __fastcall SetRowSort(int Index, TfrxCrossSortOrder Value);
	void __fastcall SetupOriginalComponent(Frxclass::TfrxComponent* Obj1, Frxclass::TfrxComponent* Obj2);
	void __fastcall UpdateVisibility(void);
	void __fastcall WriteMemos(Classes::TStream* Stream);
	Frxclass::TfrxCustomMemoView* __fastcall CreateMemo(Frxclass::TfrxComponent* Parent);
	TfrxCrossFunction __fastcall GetCellFunctions(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetCellHeaderMemos(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetCellMemos(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetColumnMemos(int Index);
	TfrxCrossSortOrder __fastcall GetColumnSort(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetColumnTotalMemos(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetCornerMemos(int Index);
	Classes::TList* __fastcall GetNestedObjects(void);
	Frxclass::TfrxCustomMemoView* __fastcall GetRowMemos(int Index);
	TfrxCrossSortOrder __fastcall GetRowSort(int Index);
	Frxclass::TfrxCustomMemoView* __fastcall GetRowTotalMemos(int Index);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall SetCellLevels(const int Value);
	virtual void __fastcall SetColumnLevels(const int Value);
	virtual void __fastcall SetRowLevels(const int Value);
	virtual Classes::TList* __fastcall GetContainerObjects(void);
	
public:
	__fastcall virtual TfrxCustomCrossView(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxCustomCrossView(void);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	virtual void __fastcall BeforePrint(void);
	virtual void __fastcall BeforeStartReport(void);
	virtual void __fastcall GetData(void);
	virtual bool __fastcall ContainerAdd(Frxclass::TfrxComponent* Obj);
	virtual bool __fastcall ContainerMouseDown(System::TObject* Sender, int X, int Y);
	virtual void __fastcall ContainerMouseMove(System::TObject* Sender, int X, int Y);
	virtual void __fastcall ContainerMouseUp(System::TObject* Sender, int X, int Y);
	void __fastcall AddValue(Variant const * Rows, const int Rows_Size, Variant const * Columns, const int Columns_Size, Variant const * Cells, const int Cells_Size);
	void __fastcall ApplyStyle(Frxclass::TfrxStyles* Style);
	void __fastcall BeginMatrix(void);
	void __fastcall EndMatrix(void);
	virtual void __fastcall FillMatrix(void);
	void __fastcall GetStyle(Frxclass::TfrxStyles* Style);
	int __fastcall ColCount(void);
	Frxclass::TfrxPoint __fastcall DrawCross(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	Variant __fastcall GetColumnIndexes(int AColumn);
	Variant __fastcall GetRowIndexes(int ARow);
	Variant __fastcall GetValue(int ARow, int AColumn, int ACell);
	virtual bool __fastcall IsCrossValid(void);
	bool __fastcall IsGrandTotalColumn(int Index);
	bool __fastcall IsGrandTotalRow(int Index);
	bool __fastcall IsTotalColumn(int Index);
	bool __fastcall IsTotalRow(int Index);
	int __fastcall RowCount(void);
	Extended __fastcall RowHeaderWidth(void);
	Extended __fastcall ColumnHeaderHeight(void);
	__property TfrxCrossColumnHeader* ColumnHeader = {read=FColumnHeader};
	__property TfrxCrossRowHeader* RowHeader = {read=FRowHeader};
	__property TfrxCrossCorner* Corner = {read=FCorner};
	__property bool NoColumns = {read=FNoColumns, nodefault};
	__property bool NoRows = {read=FNoRows, nodefault};
	__property Classes::TStrings* CellFields = {read=FCellFields, write=SetCellFields};
	__property TfrxCrossFunction CellFunctions[int Index] = {read=GetCellFunctions, write=SetCellFunctions};
	__property Frxclass::TfrxCustomMemoView* CellMemos[int Index] = {read=GetCellMemos};
	__property Frxclass::TfrxCustomMemoView* CellHeaderMemos[int Index] = {read=GetCellHeaderMemos};
	__property bool ClearBeforePrint = {read=FClearBeforePrint, write=FClearBeforePrint, nodefault};
	__property Classes::TStrings* ColumnFields = {read=FColumnFields, write=SetColumnFields};
	__property Frxclass::TfrxCustomMemoView* ColumnMemos[int Index] = {read=GetColumnMemos};
	__property TfrxCrossSortOrder ColumnSort[int Index] = {read=GetColumnSort, write=SetColumnSort};
	__property Frxclass::TfrxCustomMemoView* ColumnTotalMemos[int Index] = {read=GetColumnTotalMemos};
	__property Frxclass::TfrxCustomMemoView* CornerMemos[int Index] = {read=GetCornerMemos};
	__property bool DotMatrix = {read=FDotMatrix, nodefault};
	__property Classes::TStrings* RowFields = {read=FRowFields, write=SetRowFields};
	__property Frxclass::TfrxCustomMemoView* RowMemos[int Index] = {read=GetRowMemos};
	__property TfrxCrossSortOrder RowSort[int Index] = {read=GetRowSort, write=SetRowSort};
	__property Frxclass::TfrxCustomMemoView* RowTotalMemos[int Index] = {read=GetRowTotalMemos};
	__property TfrxOnCalcHeightEvent OnBeforeCalcHeight = {read=FOnBeforeCalcHeight, write=FOnBeforeCalcHeight};
	__property TfrxOnCalcWidthEvent OnBeforeCalcWidth = {read=FOnBeforeCalcWidth, write=FOnBeforeCalcWidth};
	__property TfrxOnPrintCellEvent OnBeforePrintCell = {read=FOnBeforePrintCell, write=FOnBeforePrintCell};
	__property TfrxOnPrintHeaderEvent OnBeforePrintColumnHeader = {read=FOnBeforePrintColumnHeader, write=FOnBeforePrintColumnHeader};
	__property TfrxOnPrintHeaderEvent OnBeforePrintRowHeader = {read=FOnBeforePrintRowHeader, write=FOnBeforePrintRowHeader};
	
__published:
	__property Extended AddHeight = {read=FAddHeight, write=FAddHeight};
	__property Extended AddWidth = {read=FAddWidth, write=FAddWidth};
	__property bool AllowDuplicates = {read=FAllowDuplicates, write=FAllowDuplicates, default=1};
	__property bool AutoSize = {read=FAutoSize, write=FAutoSize, default=1};
	__property bool Border = {read=FBorder, write=FBorder, default=1};
	__property int CellLevels = {read=FCellLevels, write=SetCellLevels, default=1};
	__property int ColumnLevels = {read=FColumnLevels, write=SetColumnLevels, default=1};
	__property int DefHeight = {read=FDefHeight, write=FDefHeight, default=0};
	__property bool DownThenAcross = {read=FDownThenAcross, write=FDownThenAcross, nodefault};
	__property int GapX = {read=FGapX, write=FGapX, default=3};
	__property int GapY = {read=FGapY, write=FGapY, default=3};
	__property bool JoinEqualCells = {read=FJoinEqualCells, write=FJoinEqualCells, default=0};
	__property int MaxWidth = {read=FMaxWidth, write=FMaxWidth, default=200};
	__property int MinWidth = {read=FMinWidth, write=FMinWidth, default=0};
	__property TfrxCustomCrossView* NextCross = {read=FNextCross, write=FNextCross};
	__property Extended NextCrossGap = {read=FNextCrossGap, write=FNextCrossGap};
	__property bool PlainCells = {read=FPlainCells, write=FPlainCells, default=0};
	__property bool RepeatHeaders = {read=FRepeatHeaders, write=FRepeatHeaders, default=1};
	__property int RowLevels = {read=FRowLevels, write=SetRowLevels, default=1};
	__property bool ShowColumnHeader = {read=FShowColumnHeader, write=FShowColumnHeader, default=1};
	__property bool ShowColumnTotal = {read=FShowColumnTotal, write=FShowColumnTotal, default=1};
	__property bool ShowCorner = {read=FShowCorner, write=FShowCorner, default=1};
	__property bool ShowRowHeader = {read=FShowRowHeader, write=FShowRowHeader, default=1};
	__property bool ShowRowTotal = {read=FShowRowTotal, write=FShowRowTotal, default=1};
	__property bool ShowTitle = {read=FShowTitle, write=FShowTitle, default=1};
	__property bool SuppressNullRecords = {read=FSuppressNullRecords, write=FSuppressNullRecords, default=1};
	__property AnsiString OnCalcHeight = {read=FOnCalcHeight, write=FOnCalcHeight};
	__property AnsiString OnCalcWidth = {read=FOnCalcWidth, write=FOnCalcWidth};
	__property AnsiString OnPrintCell = {read=FOnPrintCell, write=FOnPrintCell};
	__property AnsiString OnPrintColumnHeader = {read=FOnPrintColumnHeader, write=FOnPrintColumnHeader};
	__property AnsiString OnPrintRowHeader = {read=FOnPrintRowHeader, write=FOnPrintRowHeader};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxCustomCrossView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCrossView;
class PASCALIMPLEMENTATION TfrxCrossView : public TfrxCustomCrossView 
{
	typedef TfrxCustomCrossView inherited;
	
protected:
	virtual void __fastcall SetCellLevels(const int Value);
	virtual void __fastcall SetColumnLevels(const int Value);
	virtual void __fastcall SetRowLevels(const int Value);
	
public:
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual bool __fastcall IsCrossValid(void);
public:
	#pragma option push -w-inl
	/* TfrxCustomCrossView.Create */ inline __fastcall virtual TfrxCrossView(Classes::TComponent* AOwner) : TfrxCustomCrossView(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomCrossView.Destroy */ inline __fastcall virtual ~TfrxCrossView(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxCrossView(Classes::TComponent* AOwner, Word Flags) : TfrxCustomCrossView(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDBCrossView;
class PASCALIMPLEMENTATION TfrxDBCrossView : public TfrxCustomCrossView 
{
	typedef TfrxCustomCrossView inherited;
	
public:
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual bool __fastcall IsCrossValid(void);
	virtual void __fastcall FillMatrix(void);
	
__published:
	__property CellFields ;
	__property ColumnFields ;
	__property DataSet ;
	__property DataSetName ;
	__property RowFields ;
public:
	#pragma option push -w-inl
	/* TfrxCustomCrossView.Create */ inline __fastcall virtual TfrxDBCrossView(Classes::TComponent* AOwner) : TfrxCustomCrossView(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomCrossView.Destroy */ inline __fastcall virtual ~TfrxDBCrossView(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDBCrossView(Classes::TComponent* AOwner, Word Flags) : TfrxCustomCrossView(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxcross */
using namespace Frxcross;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxcross
