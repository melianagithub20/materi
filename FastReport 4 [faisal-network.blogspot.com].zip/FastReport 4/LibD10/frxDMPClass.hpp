// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxdmpclass.pas' rev: 10.00

#ifndef FrxdmpclassHPP
#define FrxdmpclassHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Frxunicodeutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxdmpclass
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxDMPFontStyle { fsxBold, fsxItalic, fsxUnderline, fsxSuperScript, fsxSubScript, fsxCondensed, fsxWide, fsx12cpi, fsx15cpi };
#pragma option pop

typedef Set<TfrxDMPFontStyle, fsxBold, fsx15cpi>  TfrxDMPFontStyles;

class DELPHICLASS TfrxDMPMemoView;
class PASCALIMPLEMENTATION TfrxDMPMemoView : public Frxclass::TfrxCustomMemoView 
{
	typedef Frxclass::TfrxCustomMemoView inherited;
	
private:
	TfrxDMPFontStyles FFontStyle;
	void __fastcall SetFontStyle(const TfrxDMPFontStyles Value);
	bool __fastcall IsFontStyleStored(void);
	
protected:
	virtual void __fastcall DrawFrame(void);
	virtual void __fastcall SetLeft(Extended Value);
	virtual void __fastcall SetTop(Extended Value);
	virtual void __fastcall SetWidth(Extended Value);
	virtual void __fastcall SetHeight(Extended Value);
	virtual void __fastcall SetParentFont(const bool Value);
	
public:
	__fastcall virtual TfrxDMPMemoView(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	void __fastcall ResetFontOptions(void);
	void __fastcall SetBoundsDirect(Extended ALeft, Extended ATop, Extended AWidth, Extended AHeight);
	virtual Extended __fastcall CalcHeight(void);
	virtual Extended __fastcall CalcWidth(void);
	virtual AnsiString __fastcall Diff(Frxclass::TfrxComponent* AComponent);
	
__published:
	__property AutoWidth  = {default=0};
	__property AllowExpressions  = {default=1};
	__property DataField ;
	__property DataSet ;
	__property DataSetName ;
	__property DisplayFormat ;
	__property ExpressionDelimiters ;
	__property FlowTo ;
	__property TfrxDMPFontStyles FontStyle = {read=FFontStyle, write=SetFontStyle, stored=IsFontStyleStored, nodefault};
	__property Frame ;
	__property HAlign  = {default=0};
	__property HideZeros  = {default=0};
	__property Memo ;
	__property ParentFont  = {default=1};
	__property RTLReading  = {default=0};
	__property SuppressRepeated  = {default=0};
	__property WordWrap  = {default=1};
	__property VAlign  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxCustomMemoView.Destroy */ inline __fastcall virtual ~TfrxDMPMemoView(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDMPMemoView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxCustomMemoView(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDMPLineView;
class PASCALIMPLEMENTATION TfrxDMPLineView : public Frxclass::TfrxCustomLineView 
{
	typedef Frxclass::TfrxCustomLineView inherited;
	
private:
	TfrxDMPFontStyles FFontStyle;
	void __fastcall SetFontStyle(const TfrxDMPFontStyles Value);
	bool __fastcall IsFontStyleStored(void);
	
protected:
	virtual void __fastcall SetLeft(Extended Value);
	virtual void __fastcall SetTop(Extended Value);
	virtual void __fastcall SetWidth(Extended Value);
	virtual void __fastcall SetParentFont(const bool Value);
	
public:
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual AnsiString __fastcall Diff(Frxclass::TfrxComponent* AComponent);
	
__published:
	__property TfrxDMPFontStyles FontStyle = {read=FFontStyle, write=SetFontStyle, stored=IsFontStyleStored, nodefault};
	__property ParentFont  = {default=1};
public:
	#pragma option push -w-inl
	/* TfrxCustomLineView.Create */ inline __fastcall virtual TfrxDMPLineView(Classes::TComponent* AOwner) : Frxclass::TfrxCustomLineView(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomLineView.DesignCreate */ inline __fastcall virtual TfrxDMPLineView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxCustomLineView(AOwner, Flags) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxView.Destroy */ inline __fastcall virtual ~TfrxDMPLineView(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDMPCommand;
class PASCALIMPLEMENTATION TfrxDMPCommand : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	AnsiString FCommand;
	
protected:
	virtual void __fastcall SetLeft(Extended Value);
	virtual void __fastcall SetTop(Extended Value);
	
public:
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual AnsiString __fastcall Diff(Frxclass::TfrxComponent* AComponent);
	AnsiString __fastcall ToChr();
	
__published:
	__property AnsiString Command = {read=FCommand, write=FCommand};
public:
	#pragma option push -w-inl
	/* TfrxView.Create */ inline __fastcall virtual TfrxDMPCommand(Classes::TComponent* AOwner) : Frxclass::TfrxView(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxView.Destroy */ inline __fastcall virtual ~TfrxDMPCommand(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDMPCommand(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDMPPage;
class PASCALIMPLEMENTATION TfrxDMPPage : public Frxclass::TfrxReportPage 
{
	typedef Frxclass::TfrxReportPage inherited;
	
private:
	TfrxDMPFontStyles FFontStyle;
	void __fastcall SetFontStyle(const TfrxDMPFontStyles Value);
	
protected:
	virtual void __fastcall SetPaperHeight(const Extended Value);
	virtual void __fastcall SetPaperWidth(const Extended Value);
	virtual void __fastcall SetPaperSize(const int Value);
	
public:
	__fastcall virtual TfrxDMPPage(Classes::TComponent* AOwner);
	virtual void __fastcall SetDefaults(void);
	void __fastcall ResetFontOptions(void);
	
__published:
	__property TfrxDMPFontStyles FontStyle = {read=FFontStyle, write=SetFontStyle, nodefault};
public:
	#pragma option push -w-inl
	/* TfrxReportPage.Destroy */ inline __fastcall virtual ~TfrxDMPPage(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDMPPage(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxReportPage(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxdmpclass */
using namespace Frxdmpclass;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxdmpclass
