// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frx10.pas' rev: 10.00

#ifndef Frx10HPP
#define Frx10HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Frxaggregate.hpp>	// Pascal unit
#include <Frxchm.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Frxclassrtti.hpp>	// Pascal unit
#include <Frxctrls.hpp>	// Pascal unit
#include <Frxdialogform.hpp>	// Pascal unit
#include <Frxdmpclass.hpp>	// Pascal unit
#include <Frxdmpexport.hpp>	// Pascal unit
#include <Frxdock.hpp>	// Pascal unit
#include <Frxengine.hpp>	// Pascal unit
#include <Frxgraphicutils.hpp>	// Pascal unit
#include <Frxpassw.hpp>	// Pascal unit
#include <Frxpicturecache.hpp>	// Pascal unit
#include <Frxpreview.hpp>	// Pascal unit
#include <Frxpreviewpages.hpp>	// Pascal unit
#include <Frxpreviewpagesettings.hpp>	// Pascal unit
#include <Frxprintdialog.hpp>	// Pascal unit
#include <Frxprinter.hpp>	// Pascal unit
#include <Frxprogress.hpp>	// Pascal unit
#include <Frxrcclass.hpp>	// Pascal unit
#include <Frxres.hpp>	// Pascal unit
#include <Frxsearchdialog.hpp>	// Pascal unit
#include <Frxunicodeutils.hpp>	// Pascal unit
#include <Frxutils.hpp>	// Pascal unit
#include <Frxvariables.hpp>	// Pascal unit
#include <Frxxml.hpp>	// Pascal unit
#include <Frxxmlserializer.hpp>	// Pascal unit
#include <Frxabout.hpp>	// Pascal unit
#include <Frxcodeutils.hpp>	// Pascal unit
#include <Frxconneditor.hpp>	// Pascal unit
#include <Frxcustomeditors.hpp>	// Pascal unit
#include <Frxdatatree.hpp>	// Pascal unit
#include <Frxdesgn.hpp>	// Pascal unit
#include <Frxdesgnctrls.hpp>	// Pascal unit
#include <Frxdesgneditors.hpp>	// Pascal unit
#include <Frxdesgnworkspace.hpp>	// Pascal unit
#include <Frxdesgnworkspace1.hpp>	// Pascal unit
#include <Frxdsgnintf.hpp>	// Pascal unit
#include <Frxeditaliases.hpp>	// Pascal unit
#include <Frxeditdataband.hpp>	// Pascal unit
#include <Frxeditexpr.hpp>	// Pascal unit
#include <Frxeditformat.hpp>	// Pascal unit
#include <Frxeditframe.hpp>	// Pascal unit
#include <Frxeditgroup.hpp>	// Pascal unit
#include <Frxedithighlight.hpp>	// Pascal unit
#include <Frxeditmemo.hpp>	// Pascal unit
#include <Frxeditoptions.hpp>	// Pascal unit
#include <Frxeditpage.hpp>	// Pascal unit
#include <Frxeditpicture.hpp>	// Pascal unit
#include <Frxeditreport.hpp>	// Pascal unit
#include <Frxeditreportdata.hpp>	// Pascal unit
#include <Frxeditstrings.hpp>	// Pascal unit
#include <Frxeditstyle.hpp>	// Pascal unit
#include <Frxeditsysmemo.hpp>	// Pascal unit
#include <Frxedittaborder.hpp>	// Pascal unit
#include <Frxeditvar.hpp>	// Pascal unit
#include <Frxevaluateform.hpp>	// Pascal unit
#include <Frxinheriterror.hpp>	// Pascal unit
#include <Frxinsp.hpp>	// Pascal unit
#include <Frxnewitem.hpp>	// Pascal unit
#include <Frxpopupform.hpp>	// Pascal unit
#include <Frxrcdesgn.hpp>	// Pascal unit
#include <Frxrcinsp.hpp>	// Pascal unit
#include <Frxreporttree.hpp>	// Pascal unit
#include <Frxstdwizard.hpp>	// Pascal unit
#include <Frxsynmemo.hpp>	// Pascal unit
#include <Frxunicodectrls.hpp>	// Pascal unit
#include <Frxwatchform.hpp>	// Pascal unit
#include <Frxbarcod.hpp>	// Pascal unit
#include <Frxbarcode.hpp>	// Pascal unit
#include <Frxbarcodeeditor.hpp>	// Pascal unit
#include <Frxbarcodertti.hpp>	// Pascal unit
#include <Frxchbox.hpp>	// Pascal unit
#include <Frxchboxrtti.hpp>	// Pascal unit
#include <Frxcross.hpp>	// Pascal unit
#include <Frxcrosseditor.hpp>	// Pascal unit
#include <Frxcrossrtti.hpp>	// Pascal unit
#include <Frxdctrl.hpp>	// Pascal unit
#include <Frxdctrlrtti.hpp>	// Pascal unit
#include <Frxgradient.hpp>	// Pascal unit
#include <Frxgradientrtti.hpp>	// Pascal unit
#include <Frxole.hpp>	// Pascal unit
#include <Frxoleeditor.hpp>	// Pascal unit
#include <Frxolertti.hpp>	// Pascal unit
#include <Frxrich.hpp>	// Pascal unit
#include <Frxrichedit.hpp>	// Pascal unit
#include <Frxricheditor.hpp>	// Pascal unit
#include <Frxrichrtti.hpp>	// Pascal unit
#include <Frxgzip.hpp>	// Pascal unit
#include <Frxzlib.hpp>	// Pascal unit
#include <Frxcrypt.hpp>	// Pascal unit
#include <Rc_algref.hpp>	// Pascal unit
#include <Rc_apiref.hpp>	// Pascal unit
#include <Rc_crypt.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Extdlgs.hpp>	// Pascal unit
#include <Mapi.hpp>	// Pascal unit
#include <Extactns.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Fs_iconst.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Fs_iinterpreter.hpp>	// Pascal unit
#include <Fs_iclassesrtti.hpp>	// Pascal unit
#include <Fs_igraphicsrtti.hpp>	// Pascal unit
#include <Fs_iformsrtti.hpp>	// Pascal unit
#include <Fs_ipascal.hpp>	// Pascal unit
#include <Fs_icpp.hpp>	// Pascal unit
#include <Fs_ibasic.hpp>	// Pascal unit
#include <Fs_ijs.hpp>	// Pascal unit
#include <Fs_idialogsrtti.hpp>	// Pascal unit
#include <Fs_iinirtti.hpp>	// Pascal unit
#include <Jpeg.hpp>	// Pascal unit
#include <Tabs.hpp>	// Pascal unit
#include <Checklst.hpp>	// Pascal unit
#include <Olectnrs.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frx10
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frx10 */
using namespace Frx10;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frx10
