// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Fs_idbctrlsrtti.pas' rev: 10.00

#ifndef Fs_idbctrlsrttiHPP
#define Fs_idbctrlsrttiHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Fs_iinterpreter.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit
#include <Fs_iformsrtti.hpp>	// Pascal unit
#include <Fs_idbrtti.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dbctrls.hpp>	// Pascal unit
#include <Dbgrids.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_idbctrlsrtti
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsDBCtrlsRTTI;
class PASCALIMPLEMENTATION TfsDBCtrlsRTTI : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfsDBCtrlsRTTI(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsDBCtrlsRTTI(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_idbctrlsrtti */
using namespace Fs_idbctrlsrtti;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fs_idbctrlsrtti
