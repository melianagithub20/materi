// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxeditmemo.pas' rev: 10.00

#ifndef FrxeditmemoHPP
#define FrxeditmemoHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Toolwin.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Frxeditformat.hpp>	// Pascal unit
#include <Frxedithighlight.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxeditmemo
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxMemoEditorForm;
class PASCALIMPLEMENTATION TfrxMemoEditorForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Comctrls::TPageControl* PageControl1;
	Comctrls::TTabSheet* TextTS;
	Extctrls::TPanel* Panel1;
	Stdctrls::TButton* OkB;
	Stdctrls::TButton* CancelB;
	Comctrls::TTabSheet* FormatTS;
	Comctrls::TTabSheet* HighlightTS;
	Comctrls::TToolBar* ToolBar;
	Comctrls::TToolButton* ExprB;
	Comctrls::TToolButton* AggregateB;
	Comctrls::TToolButton* LocalFormatB;
	Comctrls::TToolButton* WordWrapB;
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall WordWrapBClick(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall MemoKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall ExprBClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall AggregateBClick(System::TObject* Sender);
	void __fastcall LocalFormatBClick(System::TObject* Sender);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	Frxeditformat::TfrxFormatEditorForm* FFormat;
	Frxedithighlight::TfrxHighlightEditorForm* FHighlight;
	Frxclass::TfrxCustomMemoView* FMemoView;
	bool FIsUnicode;
	WideString FText;
	
public:
	Stdctrls::TMemo* Memo;
	__property Frxclass::TfrxCustomMemoView* MemoView = {read=FMemoView, write=FMemoView};
	__property WideString Text = {read=FText, write=FText};
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxMemoEditorForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxMemoEditorForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxMemoEditorForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxMemoEditorForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxeditmemo */
using namespace Frxeditmemo;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxeditmemo
