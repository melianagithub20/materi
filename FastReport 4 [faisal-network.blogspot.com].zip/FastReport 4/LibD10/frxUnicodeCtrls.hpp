// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxunicodectrls.pas' rev: 10.00

#ifndef FrxunicodectrlsHPP
#define FrxunicodectrlsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxunicodectrls
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUnicodeEdit;
class PASCALIMPLEMENTATION TUnicodeEdit : public Stdctrls::TEdit 
{
	typedef Stdctrls::TEdit inherited;
	
private:
	HIDESBASE void __fastcall SetSelText(const WideString Value);
	HIDESBASE WideString __fastcall GetText();
	HIDESBASE void __fastcall SetText(const WideString Value);
	
protected:
	virtual void __fastcall CreateWindowHandle(const Controls::TCreateParams &Params);
	HIDESBASE WideString __fastcall GetSelText();
	
public:
	__property WideString SelText = {read=GetSelText, write=SetSelText};
	__property WideString Text = {read=GetText, write=SetText};
public:
	#pragma option push -w-inl
	/* TCustomEdit.Create */ inline __fastcall virtual TUnicodeEdit(Classes::TComponent* AOwner) : Stdctrls::TEdit(AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TUnicodeEdit(HWND ParentWindow) : Stdctrls::TEdit(ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TUnicodeEdit(void) { }
	#pragma option pop
	
};


class DELPHICLASS TUnicodeMemo;
class PASCALIMPLEMENTATION TUnicodeMemo : public Stdctrls::TMemo 
{
	typedef Stdctrls::TMemo inherited;
	
private:
	HIDESBASE void __fastcall SetSelText(const WideString Value);
	HIDESBASE WideString __fastcall GetText();
	HIDESBASE void __fastcall SetText(const WideString Value);
	
protected:
	virtual void __fastcall CreateWindowHandle(const Controls::TCreateParams &Params);
	HIDESBASE WideString __fastcall GetSelText();
	
public:
	__property WideString SelText = {read=GetSelText, write=SetSelText};
	__property WideString Text = {read=GetText, write=SetText};
public:
	#pragma option push -w-inl
	/* TCustomMemo.Create */ inline __fastcall virtual TUnicodeMemo(Classes::TComponent* AOwner) : Stdctrls::TMemo(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomMemo.Destroy */ inline __fastcall virtual ~TUnicodeMemo(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TUnicodeMemo(HWND ParentWindow) : Stdctrls::TMemo(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxunicodectrls */
using namespace Frxunicodectrls;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxunicodectrls
