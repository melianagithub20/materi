// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxbarcod.pas' rev: 10.00

#ifndef FrxbarcodHPP
#define FrxbarcodHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxbarcod
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxBarcodeType { bcCode_2_5_interleaved, bcCode_2_5_industrial, bcCode_2_5_matrix, bcCode39, bcCode39Extended, bcCode128A, bcCode128B, bcCode128C, bcCode93, bcCode93Extended, bcCodeMSI, bcCodePostNet, bcCodeCodabar, bcCodeEAN8, bcCodeEAN13, bcCodeUPC_A, bcCodeUPC_E0, bcCodeUPC_E1, bcCodeUPC_Supp2, bcCodeUPC_Supp5, bcCodeEAN128A, bcCodeEAN128B, bcCodeEAN128C };
#pragma option pop

#pragma option push -b-
enum TfrxBarLineType { white, black, black_half };
#pragma option pop

#pragma option push -b-
enum TfrxCheckSumMethod { csmNone, csmModulo10 };
#pragma option pop

class DELPHICLASS TfrxBarcode;
class PASCALIMPLEMENTATION TfrxBarcode : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	double FAngle;
	Graphics::TColor FColor;
	Graphics::TColor FColorBar;
	bool FCheckSum;
	TfrxCheckSumMethod FCheckSumMethod;
	int FHeight;
	int FLeft;
	int FModul;
	double FRatio;
	AnsiString FText;
	int FTop;
	TfrxBarcodeType FTyp;
	Shortint modules[4];
	void __fastcall DoLines(AnsiString data, Graphics::TCanvas* Canvas);
	void __fastcall OneBarProps(char code, int &Width, TfrxBarLineType &lt);
	AnsiString __fastcall SetLen(Byte pI);
	AnsiString __fastcall Code_2_5_interleaved();
	AnsiString __fastcall Code_2_5_industrial();
	AnsiString __fastcall Code_2_5_matrix();
	AnsiString __fastcall Code_39();
	AnsiString __fastcall Code_39Extended();
	AnsiString __fastcall Code_128();
	AnsiString __fastcall Code_93();
	AnsiString __fastcall Code_93Extended();
	AnsiString __fastcall Code_MSI();
	AnsiString __fastcall Code_PostNet();
	AnsiString __fastcall Code_Codabar();
	AnsiString __fastcall Code_EAN8();
	AnsiString __fastcall Code_EAN13();
	AnsiString __fastcall Code_UPC_A();
	AnsiString __fastcall Code_UPC_E0();
	AnsiString __fastcall Code_UPC_E1();
	AnsiString __fastcall Code_Supp5();
	AnsiString __fastcall Code_Supp2();
	void __fastcall MakeModules(void);
	int __fastcall GetWidth(void);
	AnsiString __fastcall DoCheckSumming(const AnsiString data);
	AnsiString __fastcall MakeData();
	
public:
	__fastcall virtual TfrxBarcode(Classes::TComponent* Owner);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	void __fastcall DrawBarcode(Graphics::TCanvas* Canvas, const Types::TRect &ARect, bool ShowText);
	
__published:
	__property AnsiString Text = {read=FText, write=FText};
	__property int Modul = {read=FModul, write=FModul, nodefault};
	__property double Ratio = {read=FRatio, write=FRatio};
	__property TfrxBarcodeType Typ = {read=FTyp, write=FTyp, nodefault};
	__property bool Checksum = {read=FCheckSum, write=FCheckSum, nodefault};
	__property TfrxCheckSumMethod CheckSumMethod = {read=FCheckSumMethod, write=FCheckSumMethod, nodefault};
	__property double Angle = {read=FAngle, write=FAngle};
	__property int Width = {read=GetWidth, nodefault};
	__property int Height = {read=FHeight, write=FHeight, nodefault};
	__property Graphics::TColor Color = {read=FColor, write=FColor, nodefault};
	__property Graphics::TColor ColorBar = {read=FColorBar, write=FColorBar, nodefault};
public:
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxBarcode(void) { }
	#pragma option pop
	
};


#pragma pack(push,1)
struct TBCdata
{
	
public:
	AnsiString Name;
	bool num;
} ;
#pragma pack(pop)

typedef TBCdata frxBarcod__2[23];

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TBCdata BCdata[23];

}	/* namespace Frxbarcod */
using namespace Frxbarcod;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxbarcod
